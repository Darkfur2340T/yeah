#Plugin by @Rishisuperyo
#Animation by kiddo
#kang =gey ,keep credits = cool coder 😶
#usage .gim
from telethon import events
import asyncio
from userbot.utils import lightning_cmd
from userbot import CMD_HELP
@borg.on(lightning_cmd(pattern=r"gim", outgoing=True))
async def hapy(event):

     a="🎱➖✊➖➖✊➖🎱\n🌟        \         /          🌟\n⭐          \😁/            ⭐\n✨           🎽             ✨\n              /    \ \n            👟    👟"
     await event.edit(a)
	
