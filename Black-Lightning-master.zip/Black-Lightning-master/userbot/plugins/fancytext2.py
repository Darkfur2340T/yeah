# keep credit if u gonna edit or kang it
# without creadit copy paster mc
# creadits to  sawan(@veryhelpful) learned from kraken


import asyncio

from uniborg.util import lightning_cmd


@borg.on(lightning_cmd(pattern="lovu ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit("love u 😘")
        await asyncio.sleep(0.2)
        await event.edit("love u bro")
        await asyncio.sleep(0.2)
        await event.edit("love u babes")
        await asyncio.sleep(0.2)
        await event.edit("love u sir")
        await asyncio.sleep(0.2)
        await event.edit("love u sister")
        await asyncio.sleep(0.2)
        await event.edit("love u lol")
        await asyncio.sleep(0.2)
        await event.edit(
            "╔╗─╔═╗╔╗─╔╗╔═╗     ╔╦╗\n║║─║║║║╚╦╝║║╦╝     ║║║\n║╚╗║║║╚╗║╔╝║╩╗     ║║║\n╚═╝╚═╝─╚═╝─╚═╝     ╚═╝"
        )


@borg.on(lightning_cmd(pattern="plz ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit("please🥺🥺🥺🥺🥺 ")
        await asyncio.sleep(1.3)
        await event.edit(
            "╔═╗╔╗─╔═╗╔══╗╔══╗╔═╗\n║╬║║║─║╦╝║╔╗║║══╣║╦╝\n║╔╝║╚╗║╩╗║╠╣║╠══║║╩╗\n╚╝─╚═╝╚═╝╚╝╚╝╚══╝╚═╝"
        )


@borg.on(lightning_cmd(pattern="wtbf ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit("what the fuck bro")
        await asyncio.sleep(0.2)
        await event.edit("what the fuck lol")
        await asyncio.sleep(0.2)
        await event.edit("what the fuck idiot")
        await asyncio.sleep(0.2)
        await event.edit("╔╦═╦╗╔══╗╔══╗\n║║║║║╚╗╔╝║═╦╝\n║║║║║─║║─║╔╝─\n╚═╩═╝─╚╝─╚╝──")


@borg.on(lightning_cmd(pattern="fyes ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit("yes,ehy not")
        await asyncio.sleep(1)
        await event.edit("╔═╦╗╔═╗╔══╗\n╚╗║║║╦╝║══╣\n╔╩╗║║╩╗╠══║\n╚══╝╚═╝╚══╝")


@borg.on(lightning_cmd(pattern="fno ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit("no never ")
        await asyncio.sleep(1)
        await event.edit("╔═╦╗╔═╗\n║║║║║║║\n║║║║║║║\n╚╩═╝╚═╝")


@borg.on(lightning_cmd(pattern="fbad ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit("very bad , i didnt like it")
        await asyncio.sleep(1)
        await event.edit("╔══╗╔══╗╔══╗\n║╔╗║║╔╗║╚╗╗║\n║╔╗║║╠╣║╔╩╝║\n╚══╝╚╝╚╝╚══╝")


@borg.on(lightning_cmd(pattern="fgd ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit(
            "╔═╗───────╔╗ ─╔╗────╔╦╗\n║╬║╔═╗╔═╗╔╝║ ╔╝║╔═╗─║║║\n╠╗║║╬║║╬║║╬║ ║╬║║╬╚╗╠╗║\n╚═╝╚═╝╚═╝╚═╝ ╚═╝╚══╝╚═╝"
        )


@borg.on(lightning_cmd(pattern="noice ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit(
            "╔═╦╗╔══╗╔═╗╔═╗\n║║║║╚║║╝║╔╝║╦╝\n║║║║╔║║╗║╚╗║╩╗\n╚╩═╝╚══╝╚═╝╚═╝"
        )


@borg.on(lightning_cmd(pattern="really ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit(
            "╔═╗╔═╗╔══╗╔╗─╔╗─╔═╦╗\n║╬║║╦╝║╔╗║║║─║║─╚╗║║\n║╗╣║╩╗║╠╣║║╚╗║╚╗╔╩╗║\n╚╩╝╚═╝╚╝╚╝╚═╝╚═╝╚══╝"
        )


@borg.on(lightning_cmd(pattern="ooh ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit("╔═╗╔═╗╔═╗╔╗╔╗\n║║║║║║║║║║╚╝║\n║║║║║║║║║║╔╗║\n╚═╝╚═╝╚═╝╚╝╚╝")


@borg.on(lightning_cmd(pattern="maker ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit(
            "╔══╗╔══╗╔╦═╦╗╔══╗╔═╦╗\n║══╣║╔╗║║║║║║║╔╗║║║║║\n╠══║║╠╣║║║║║║║╠╣║║║║║\n╚══╝╚╝╚╝╚═╩═╝╚╝╚╝╚╩═╝"
        )


@borg.on(lightning_cmd(pattern="pgl ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit(
            "╔═╗╔══╗╔══╗╔══╗╔╗─\n║╬║║╔╗║║╔═╣║╔╗║║║─\n║╔╝║╠╣║║╚╗║║╠╣║║╚╗\n╚╝─╚╝╚╝╚══╝╚╝╚╝╚═╝"
        )
