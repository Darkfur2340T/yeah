"""Fun pligon...for HardcoreUserbot
\nCode by @veryhelpful
type `.gm` and to see the fun.-
"""
import asyncio

from uniborg.util import lightning_cmd


@borg.on(lightning_cmd(pattern="egm ?(.*)"))
async def _(event):
    if not event.text[0].isalpha() and event.text[0] not in ("/", "#", "@", "!"):
        await event.edit(
            ".     😍😊😍😊😍😍\n 😊😍😍😍😍😊😍😊\n  😍😊                     😊😊\n 😍😍\n😍😊                😊😍😊😍\n😍😊                😍😊😊😊\n😍😊                        😊😍\n   😊😊                      😍😍\n     😍😊😍😍😍😊😊😍  \n          😊😊😊😍😍😊 "
        )
        await asyncio.sleep(2)
        await event.edit(
            ".           😍😊😊😊😍\n 😍😊😍😍😊😍😊\n   😍😊                   😊😍\n 😍😊                       😍😊\n😊😍                         😍😍\n😊😊                         😍😍\n 😊😊                       😍😍\n   😊😊                   😍😊\n      😍😍😍😍😍😍😊\n            😊😊😍😍😍"
        )
        await asyncio.sleep(2)
        await event.edit(
            ".           😊😊😍😊😊\n     😊😍😍😍😊😍😊\n   😊😍                   😍😊\n 😊😊                       😍😊\n😍😍                         😍😊\n😍😍                         😊😊\n 😍😊                       😍😍\n   😊😍                   😊😊\n      😊😊😍😍😊😊😊\n            😍😊😊😊😊"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😊😍😊😍😊😍😊\n😍😍😍😊😍😍😍😊\n😍😊                      😊😊\n😊😊                         😊😊\n😍😊                         😊😍\n😍😍                         😊😊\n😍😊                         😊😊\n😊😍                      😍😊\n😊😍😍😍😊😊😊😊\n😊😊😊😍😍😊😍\n\n"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😍😊                              😍😍\n😊😍😊                      😍😊😊\n😍😊😍😊            😊😊😊😍\n😊😊    😊😊    😊😊    😊😊\n😊😊        😊😊😊        😍😍\n😊😊             😍             😍😊\n😍😊                              😍😊\n😊😍                              😊😊\n😍😍                              😊😊\n😊😊                              😍😊"
        )
        await asyncio.sleep(2)
        await event.edit(
            ".           😍😊😊😊😍\n 😍😊😍😍😊😍😊\n   😍😊                   😊😍\n 😍😊                       😍😊\n😊😍                         😍😍\n😊😊                         😍😍\n 😊😊                       😍😍\n   😊😊                   😍😊\n      😍😍😍😍😍😍😊\n            😊😊😍😍😍"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😍😍😍😊😍😊😍\n😍😊😍😍😊😊😊😊\n😍😊                     😍😍\n😊😍                     😍😍\n😊😍😍😍😊😊😊😊\n😍😊😍😍😊😍😍\n😊😊    😍😊\n😍😍         😍😊\n😊😊              😊😊\n😊😊                  😍😊"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😊😍                           😍😍\n😍😍😊                       😊😍\n😊😊😍😍                 😍😊\n😍😍  😊😊               😍😊\n😍😊     😊😊            😊😊\n😊😍         😊😊        😍😊\n😊😍             😍😍    😍😍\n😊😍                 😊😍😊😊\n😍😊                     😊😍😊\n😍😊                          😊😍"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😊😊😊😍😊😍\n😊😍😊😍😍😍\n          😍😍\n          😍😍\n          😍😊\n          😍😊\n          😊😊\n          😊😊\n😍😊😍😊😊\n😊😍😍😊😊😊"
        )
        await asyncio.sleep(2)
        await event.edit(
            "😊😍                           😍😍\n😍😍😊                       😊😍\n😊😊😍😍                 😍😊\n😍😍  😊😊               😍😊\n😍😊     😊😊            😊😊\n😊😍         😊😊        😍😊\n😊😍             😍😍    😍😍\n😊😍                 😊😍😊😊\n😍😊                     😊😍😊\n😍😊                          😊😍"
        )
        await asyncio.sleep(2)
        await event.edit(
            ".     😍😊😍😊😍😍\n 😊😍😍😍😍😊😍😊\n  😍😊                     😊😊\n 😍😍\n😍😊                😊😍😊😍\n😍😊                😍😊😊😊\n😍😊                        😊😍\n   😊😊                      😍😍\n     😍😊😍😍😍😊😊😍  \n          😊😊😊😍😍😊 "
        )
        await asyncio.sleep(2)
        await event.edit("GOOD MORNING ,HAVE A NICE DAY AHAED😊")
